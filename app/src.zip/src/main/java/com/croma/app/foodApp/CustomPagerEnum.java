package com.croma.app.foodApp;

/**
 * Created by suppi on 10/07/16.
 */
public enum CustomPagerEnum {

    RED(R.string.accept, R.layout.fragment_order),
    BLUE(R.string.accept, R.layout.activity_login),
    ORANGE(R.string.accept, R.layout.activity_forgetpassword);

    private int mTitleResId;
    private int mLayoutResId;

    CustomPagerEnum(int titleResId, int layoutResId) {
        mTitleResId = titleResId;
        mLayoutResId = layoutResId;
    }

    public int getTitleResId() {
        return mTitleResId;
    }

    public int getLayoutResId() {
        return mLayoutResId;
    }
}
