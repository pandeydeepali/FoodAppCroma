package com.croma.app.foodApp;

/**
 * Created by suppi on 02/07/16.
 */
public interface GlobalInterFace {
     void findViewById();
     void setOnClickListener();
     void applyFont();
     void OnitemSelect();



}


