package com.croma.app.foodApp;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.utll.global.CustomControl;
import com.utll.global.Validation;

/**
 * Created by suppi on 29/06/16.
 */
public class SignUpActivity extends AppCompatActivity implements GlobalInterFace, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {
     //----SignUp View Control
    private Button RegButton;
    private ImageView regBack;
    private EditText regName, regEmail, regPass, regcPass, regPhone, regAddress;
    private ProgressDialog progressDialog = null;

    //-------------------------//
    private static final String TAG = SignUpActivity.class.getSimpleName();
    /**
     * The desired interval for location updates. Inexact. Updates may be more or less frequent.
     */
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;

    /**
     * The fastest rate for active location updates. Exact. Updates will never be more frequent
     * than this value.
     */
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2;
     // Keys for storing activity state in the Bundle.
    private final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    private final static String LOCATION_KEY = "location-key";
    private final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";

    /**
     * Provides the entry point to Google Play services.
     */
    private GoogleApiClient mGoogleApiClient;

    /**
     * Stores parameters for requests to the FusedLocationProviderApi.
     */
    private LocationRequest mLocationRequest;

    /**
     * Represents a geographical location.
     */
    private Location mCurrentLocation;



    //------------------------//


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate ...............................");
        //show error dialog if GoolglePlayServices not available
        setContentView(R.layout.activity_registration);
        findViewById();
        setOnClickListener();
     }



    @Override
    public void findViewById() {
        regBack = (ImageView) findViewById(R.id.regBack);
        regName = (EditText) findViewById(R.id.regName);
        regEmail = (EditText) findViewById(R.id.regEmail);
        regPass = (EditText) findViewById(R.id.regPass);
        regcPass = (EditText) findViewById(R.id.regcPass);
        regPhone = (EditText) findViewById(R.id.regPhone);
        regAddress = (EditText) findViewById(R.id.regAddress);
        RegButton = (Button) findViewById(R.id.RegButton);
     }

    @Override
    public void setOnClickListener() {
        regBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        RegButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Validation.hasText(regName) && !Validation.hasText(regEmail) && !Validation.hasText(regPass) &&
                        !Validation.hasText(regcPass) && !Validation.hasText(regPhone) && !Validation.hasText(regAddress)) {
                } else if (!Validation.isValidEmailAddress(regEmail, Validation.EMAIL_REGEX, "InValid Email Address", true)) {

                } else if (!Validation.isValid(regPass, Validation.PASSWORD_REGEX, "Password Should be alphanumeric with specialCharacter", true)) {

                } else if (!Validation.isValid(regcPass, Validation.PASSWORD_REGEX, "Password Should be alphanumeric with specialCharacter", true)) {

                } else if (!regPass.getText().toString().trim().equals(regcPass.getText().toString().trim())) {
                    regPass.setError("Password and Confirm Password Should be matched");
                    regcPass.setError(null);
                } else if (regPhone.getText().toString().trim().length() != 10) {
                    regPhone.setError(" 10 characters required");
                } else if (!Validation.isPhoneNumber(regPhone, false)) {


                } else {
                    //UtilGlobalMethod.removeFocusOnRegControl();
                    progressDialog = ProgressDialog.show(
                            SignUpActivity.this, "PLEASE WAIT.",
                            "REGISTERING...", true);
                    regAddress.setError(null);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                             Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                                CustomControl.successAlert(SignUpActivity.this, "Success", "Thank You For Registration");
                                startActivity(intent);
                            } catch (Exception e) {
                                e.printStackTrace();

                            }
                            progressDialog.dismiss();
                            overridePendingTransition(R.anim.slide_in_left,
                                    R.anim.slide_out_right);
                        }
                    }, 3000);
                }
            }
        });
    }


    @Override
    public void applyFont() {

    }

    @Override
    public void OnitemSelect() {

    }

    @Override
    public void onConnected(Bundle bundle) {
        Log.d(TAG, "onConnected - isConnected");

    }

    public void startLocationUpdates() {
        Log.e("start Location", "Success");

    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.e("suspened", "Fail"+i);

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.e("Failure", "Fail"+connectionResult);

    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "Firing onLocationChanged..............................................");

    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    protected void stopLocationUpdates() {
        Log.d(TAG, "Location update stopped .......................");
    }

    @Override
    public void onResume() {
        super.onResume();

    }

}
