package com.croma.app.foodApp;

/**
 * Created by suppi on 04/07/16.
 */
public class GlobalsharedPreference {
    public static final String loginsharedPREFERENCES = "LoginFormPreferences" ;

}
