package com.croma.app.foodApp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by suppi on 05/07/16.
 */
public class SnackbarActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.snackbar_layout);
        final View coordinatorLayoutView = findViewById(R.id.snackbarPosition);
        Snackbar.make(coordinatorLayoutView, "Internet Problem", Snackbar.LENGTH_LONG).show();

    }
}